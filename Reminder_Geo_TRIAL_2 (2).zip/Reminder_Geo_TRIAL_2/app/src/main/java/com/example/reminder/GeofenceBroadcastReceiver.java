package com.example.reminder;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.location.Location;
import android.os.AsyncTask;
import android.util.Log;
import android.widget.Toast;

import com.google.android.gms.location.Geofence;
import com.google.android.gms.location.GeofencingEvent;

import java.util.List;

public class GeofenceBroadcastReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {

        Toast.makeText(context, "Geofence Triggered...", Toast.LENGTH_LONG).show();
        Log.i("Geofence trigger :", "Success");

        NotificationHelper notificationHelper = new NotificationHelper(context);



        GeofencingEvent geofencingEvent = GeofencingEvent.fromIntent(intent);

        if (geofencingEvent.hasError()) {
            Log.i("onReceive :", "Error receiving Geofence event ...");
            return;
        }
        // we are getting a list of geofences bcz there might be chance of triggering of more than one geofences
        List<Geofence> geofenceList = geofencingEvent.getTriggeringGeofences();
        //location of current point at which geofence triggered
        //Location location = geofencingEvent.getTriggeringLocation();
        for (Geofence geofence : geofenceList) {
            Log.i("Receiving : ", geofence.toString());
            Log.i("Receiving : ", geofence.getRequestId());

            int transitionType = geofencingEvent.getGeofenceTransition();
            switch (transitionType) {
                case Geofence.GEOFENCE_TRANSITION_ENTER:
                    Toast.makeText(context, "GEOFENCE_TRANSITION_ENTER", Toast.LENGTH_SHORT).show();
                    notificationHelper.sendHighPriorityNotification("Location Enter", "", MapsActivity.class);
                    break;
                case Geofence.GEOFENCE_TRANSITION_EXIT:
                    Toast.makeText(context, "GEOFENCE_TRANSITION_EXIT", Toast.LENGTH_SHORT).show();
                    notificationHelper.sendHighPriorityNotification("Location Exit", "", MapsActivity.class);
                    break;
                case Geofence.GEOFENCE_TRANSITION_DWELL:
                    Toast.makeText(context, "GEOFENCE_TRANSITION_DWELL / INSIDE", Toast.LENGTH_SHORT).show();
                    notificationHelper.sendHighPriorityNotification("Roaming inside Location ", "", MapsActivity.class);
                    break;
            }
            PendingResult pendingResult = goAsync();
            new Task(pendingResult, intent).execute();
        }
        //  throw new UnsupportedOperationException("Not yet implemented");
    }

    private static class Task extends AsyncTask<Void, Void, Void> {
        PendingResult pendingResult;
        Intent intent;

        public Task(PendingResult pendingResult, Intent intent) {
            this.pendingResult = pendingResult;
            this.intent = intent;
        }

        @Override
        protected Void doInBackground(Void... voids) {
            try {
                Log.i("in Background :", "Work Started ...");
                Thread.sleep(5000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            Log.i("onPost Execute :", "Work Finished ...");
            pendingResult.finish();
        }
    }
}
