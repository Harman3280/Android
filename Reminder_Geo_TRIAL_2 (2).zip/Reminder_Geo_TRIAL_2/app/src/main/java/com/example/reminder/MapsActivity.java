package com.example.reminder;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentActivity;

import android.Manifest;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.IntentSender;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.Location;
import android.os.Build;
import android.os.Bundle;
import android.os.Looper;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.common.api.ResolvableApiException;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.Geofence;
import com.google.android.gms.location.GeofencingClient;
import com.google.android.gms.location.GeofencingRequest;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.LocationSettingsRequest;
import com.google.android.gms.location.LocationSettingsResponse;
import com.google.android.gms.location.SettingsClient;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.CircleOptions;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.maps.android.SphericalUtil;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class MapsActivity extends FragmentActivity implements OnMapReadyCallback, GoogleMap.OnMapLongClickListener {

    private GoogleMap mMap;
    private GeofencingClient geofencingClient;
    private int fineRequestCode = 101;
    private LatLng userLocation,markerLocation;
    FusedLocationProviderClient fusedLocationProviderClient;
    private LocationRequest locationRequest;
    private LocationCallback locationCallback;
    private int BACKGROUND_LOCATION_ACCESS_REQUEST_CODE = 102;
    private Double rr;  //radius of Geofence
    private Double distance;
    private GeofenceHelper geofenceHelper;
    private String GEOFENCE_ID = "";
    private static final String TAG = "MapsActivity";
    static ArrayList<Integer>list=new ArrayList<>();
    TextView curLocation;


    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == fineRequestCode) {

            if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                //if permission for location is granted
                mMap.setMyLocationEnabled(true);
                getCurrLocation();
            } else {
                Toast.makeText(this, "This app requires location permission", Toast.LENGTH_SHORT).show();
                finish();
                //we don't have the permission
            }
        }
        if (requestCode == BACKGROUND_LOCATION_ACCESS_REQUEST_CODE) {

            if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_BACKGROUND_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                //if permission for location is granted
                mMap.setMyLocationEnabled(true);
                getCurrLocation();
            } else {
                Toast.makeText(this, "Requires Background location permission", Toast.LENGTH_SHORT).show();
                finish();
                //we don't have the permission
            }
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);

        geofencingClient = LocationServices.getGeofencingClient(this);
        curLocation =(TextView)findViewById(R.id.curLocation);
        fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this);
      //  locationRequest = LocationRequest.create();
      //  locationRequest.setInterval(4000).setFastestInterval(2000).setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
        locationCallback = new LocationCallback(){
            @Override
            public void onLocationResult(LocationResult locationResult) {
                super.onLocationResult(locationResult);
                if (locationResult == null)
                    return;

                Location location = locationResult.getLastLocation();
                LocationResultHelper locationResultHelper = new LocationResultHelper(MapsActivity.this,location);
                locationResultHelper.showNotification();

             //   Toast.makeText(MapsActivity.this, String.valueOf(location), Toast.LENGTH_SHORT).show();

                Log.d(TAG,"onLocationResult ---- Location -----"+String.valueOf(location));
                curLocation.setText(String.valueOf(location.getLongitude())+"--"+ String.valueOf(location.getLatitude()));
                userLocation = new LatLng(location.getLatitude(), location.getLongitude());

                gotoLocation(userLocation);



            }
        };

        geofenceHelper = new GeofenceHelper(this);

    }


    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        Intent intent = getIntent();
        rr = intent.getDoubleExtra("rr", 0);

        enableUserLocation();
        getCurrLocation();
       // checkDeviceSettingNStartUpdates();
        mMap.setOnMapLongClickListener(this);
        //mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(userLocation, 15.5f));
    }

   /* private void checkDeviceSettingNStartUpdates()
    {
        LocationSettingsRequest request =new LocationSettingsRequest.Builder().addLocationRequest(locationRequest).build();
        SettingsClient client =LocationServices.getSettingsClient(this);

        Task<LocationSettingsResponse> locationSettingsResponseTask =client.checkLocationSettings(request);
        locationSettingsResponseTask.addOnSuccessListener(new OnSuccessListener<LocationSettingsResponse>() {
            @Override
            public void onSuccess(LocationSettingsResponse locationSettingsResponse) {
                //settings of device are ok to start locatio updates

                startLocationUpdates();
            }
        });
        locationSettingsResponseTask.addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                if(e instanceof ResolvableApiException)
                {
                    ResolvableApiException apiException = (ResolvableApiException) e;
                    try {
                        apiException.startResolutionForResult(MapsActivity.this,100);
                    } catch (IntentSender.SendIntentException ex) {
                        ex.printStackTrace();
                    }
                }
            }
        });
    }*/

   /* private void startLocationUpdates()
    {
        fusedLocationProviderClient.requestLocationUpdates(locationRequest , locationCallback, Looper.getMainLooper());
    }

    private void stopLocationUpdates()
    {
       fusedLocationProviderClient.removeLocationUpdates(locationCallback);
    }*/
    private void gotoLocation(LatLng latLng)
    {
       // mMap.clear();
      //  MarkerOptions markerOptions=new MarkerOptions().position(latLng).icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_GREEN));
      //  mMap.addMarker(markerOptions);
        mMap.setMyLocationEnabled(true);

    }

    private void getCurrLocation() {
        locationRequest = LocationRequest.create();
        locationRequest.setInterval(5000).setFastestInterval(3000).setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
        fusedLocationProviderClient.requestLocationUpdates(locationRequest,locationCallback,Looper.getMainLooper());
      /*  Task<Location> locationTask = fusedLocationProviderClient.getLastLocation();

        locationTask.addOnSuccessListener(new OnSuccessListener<Location>() {
            @Override
            public void onSuccess(Location location) {
                if (location != null) {
                    userLocation = new LatLng(location.getLatitude(), location.getLongitude());
                    mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(userLocation, 11.5f));
                } else {
                    //Not Found
                }
            }
        });
        locationTask.addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Log.i("Error", "Not Found");
            }
        });*/
    }

    private void enableUserLocation() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            //if permission for location is granted
           // mMap.setMyLocationEnabled(true);
            getCurrLocation();
        } else {
            //if not granted ask for it
            if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.ACCESS_FINE_LOCATION)) {
                //show user a dialogue box that why you need a permission and them ask for it
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, fineRequestCode);
            } else {
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, fineRequestCode);
            }
        }
    }

    @Override
    public void onMapLongClick(LatLng latLng) {

        if (Build.VERSION.SDK_INT >= 29) {
            //We need background permission
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_BACKGROUND_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                handleMapLongClick(latLng);
            } else {
                if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.ACCESS_BACKGROUND_LOCATION)) {
                    //we request for permission by showing a dialog
                    ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_BACKGROUND_LOCATION}, BACKGROUND_LOCATION_ACCESS_REQUEST_CODE);
                } else {
                    ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_BACKGROUND_LOCATION}, BACKGROUND_LOCATION_ACCESS_REQUEST_CODE);
                }
            }
        } else {
            handleMapLongClick(latLng);
        }


    }

    private void handleMapLongClick(LatLng latLng) {
        mMap.clear();
        markerLocation=latLng;
        AddMarker(latLng);
        AddCircle(latLng, rr);
       /* float Geo_radius = rr.floatValue();
        addGeofence(latLng, Geo_radius);

        Double lt = latLng.latitude, lg = latLng.longitude;
        customizeTask.Latitude.setText(Double.toString(lt));
        customizeTask.Longitude.setText(Double.toString(lg));*/
        distance = SphericalUtil.computeDistanceBetween(userLocation, latLng);
        Toast.makeText(this, Math.ceil(distance ) + " metre(s) apart", Toast.LENGTH_SHORT).show();
    }

    private void addGeofence(LatLng latLng, float radius) {

        Log.i(" Geofence Location: ", String.valueOf(latLng));
        Log.i(" Geofence Radius: ", String.valueOf(radius));
        Random rand = new Random();
        int id = rand.nextInt(100)+1;
       /* for(int ii : list){
            Log.i("id",Integer.toString(ii));
        }
        Log.i(" Geofence Location: ", String.valueOf(latLng));*/
        if(list.isEmpty()){
            list.add(id);
            GEOFENCE_ID=Integer.toString(id);
        }else{
            while(list.contains(id))
                id=rand.nextInt(100)+1;
            list.add(id);
            GEOFENCE_ID=Integer.toString(id);
        }/*
        for(int ii : list){
            Log.i("id",Integer.toString(ii));
        }*/
        Geofence geofence = geofenceHelper.getGeofence(GEOFENCE_ID, latLng, radius, Geofence.GEOFENCE_TRANSITION_ENTER | Geofence.GEOFENCE_TRANSITION_EXIT | Geofence.GEOFENCE_TRANSITION_DWELL);   //transition is set to ENTER ONLY
        GeofencingRequest geofencingRequest = geofenceHelper.getGeofencingRequest(geofence);
        PendingIntent pendingIntent = geofenceHelper.getPendingIntent();



        geofencingClient.addGeofences(geofencingRequest, pendingIntent)     // fir se permission chk mang ra no problem already done
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        Log.d(TAG, "onSuccess : Geofence Added Successfully");
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        String errorMsg = geofenceHelper.getErrorString(e);
                        Log.d(TAG, "onFailure" + errorMsg);
                    }
                });
    }
    public void confirmGeofence(View view){
        float Geo_radius = rr.floatValue();
        addGeofence(markerLocation, Geo_radius);
        Double lt = markerLocation.latitude, lg = markerLocation.longitude;
        customizeTask.Latitude.setText(Double.toString(lt));
        customizeTask.Longitude.setText(Double.toString(lg));
        distance = SphericalUtil.computeDistanceBetween(userLocation, markerLocation);
        Toast.makeText(this, distance / 1000 + " km apart location saved..!!", Toast.LENGTH_SHORT).show();
        finish();
    }
    private void AddMarker(LatLng latLng){
        MarkerOptions markerOptions=new MarkerOptions().position(latLng);
        mMap.addMarker(markerOptions);
        // Toast.makeText(this,"Location Saved !",Toast.LENGTH_LONG);
    }
    private void AddCircle(LatLng latLng,double radius){
        CircleOptions circleOptions=new CircleOptions();
        circleOptions.center(latLng);
        circleOptions.radius(radius);
        circleOptions.strokeColor(Color.argb(255,255,0,0));
        circleOptions.fillColor(Color.argb(64,255,0,0));
        circleOptions.strokeWidth(4);
        mMap.addCircle(circleOptions);
    }
}