package com.example.reminder;

import android.app.TaskStackBuilder;
import android.content.Context;
import android.content.Intent;
import android.location.Location;
import android.widget.Toast;

public class LocationResultHelper {
    private Context context;
    Location location;

    public LocationResultHelper(Context context , Location location)
    {
        this.context=context;
        this.location=location;

    }
    public void showNotification()
    {
        NotificationHelper notificationHelper = new NotificationHelper(context);
        Toast.makeText(context,"background Loc :"+String.valueOf(location),Toast.LENGTH_SHORT).show();
        notificationHelper.sendHighPriorityNotification("background Loc :"+String.valueOf(location), "", MainActivity.class);

        //Construct a task stack
           }

}
