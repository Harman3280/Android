package com.example.reminder;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class MainActivity extends AppCompatActivity {

    private RecyclerView datalist;
    private DatabaseReference mDatabase;
    private TextView addnewtask;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mDatabase= FirebaseDatabase.getInstance().getReference().child("Members");
        mDatabase.keepSynced(true);

        datalist=(RecyclerView)findViewById(R.id.recycler_view);
        datalist.setHasFixedSize(true);
        datalist.setLayoutManager(new LinearLayoutManager(this));
        addnewtask=findViewById(R.id.addnewtask);
        addnewtask.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this,customizeTask.class));
            }
        });
    }

    @Override
    protected void onStart() {
        super.onStart();
        FirebaseRecyclerAdapter<Data,myViewHolder> firebaseRecyclerAdapter=new FirebaseRecyclerAdapter<Data, myViewHolder>
                (Data.class,R.layout.row,myViewHolder.class,mDatabase) {
            @Override
            protected void populateViewHolder(myViewHolder viewHolder, Data data, int i) {
                viewHolder.setTask(data.getTask());
                viewHolder.setLatitude(data.getLat());
                viewHolder.setLongitude(data.getLon());
                viewHolder.setRadius(data.getRadius());

            }
        };
        datalist.setAdapter(firebaseRecyclerAdapter);

    }
    public  static  class myViewHolder extends RecyclerView.ViewHolder
    {
        View mView;

        public myViewHolder(@NonNull View itemView) {
            super(itemView);
            mView=itemView;
        }
        public void setTask(String task) {
            TextView task_text = (TextView) mView.findViewById(R.id.task_textview);
            task_text.setText(task);
        }
        public void setLatitude(String lat)
        {
            TextView lati_text=(TextView) mView.findViewById(R.id.lat_text);
            lati_text.setText(lat);
        }
        public void setLongitude(String lon)
        {
            TextView loni_text=(TextView) mView.findViewById(R.id.lon_text);
            loni_text.setText(lon);
        }
        public void setRadius(String radius)
        {
            TextView radi_text=(TextView) mView.findViewById(R.id.radius_txt);
            radi_text.setText(radius);
        }
    }
}