package com.example.reminder;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class customizeTask extends AppCompatActivity {

    EditText reminderRange,taskName;
    static TextView Latitude,Longitude ;
   // private Button savebtn;
    DatabaseReference ref;
    Data data;
    // static Double lt,lg;
    public void saveTask(View view){
      /*  taskName=(EditText)findViewById(R.id.taskName);
        reminderRange= (EditText)findViewById(R.id.reminderRange);
        Latitude=(TextView)findViewById(R.id.Latitude);
        Longitude=(TextView)findViewById(R.id.Longitude);*/

        if(TextUtils.isEmpty(taskName.getText().toString())){
            Toast.makeText(this,"Please enter the task name",Toast.LENGTH_LONG).show();
        }else if(TextUtils.isEmpty(reminderRange.getText().toString()) ||TextUtils.isEmpty(Latitude.getText().toString()) || TextUtils.isEmpty(Longitude.getText().toString())){
            Toast.makeText(this,"Please set the location first!!",Toast.LENGTH_LONG).show();
        }
        else{
           // String name=taskName.getText().toString();
          //  MainActivity.task.add(name);
          //  MainActivity.arrayAdapter.notifyDataSetChanged();
            String task=taskName.getText().toString().trim();
            String latitude=Latitude.getText().toString().trim();
            String longitude=Longitude.getText().toString().trim();
            String remRange=reminderRange.getText().toString().trim();


            data.setTask(task);
            data.setLat(latitude);
            data.setLon(longitude);
            data.setRadius(remRange);
            ref.push().setValue(data);

            Toast.makeText(customizeTask.this,"Data added Successfully",Toast.LENGTH_SHORT).show();
          //  Toast.makeText(this,"Task Saved",Toast.LENGTH_SHORT).show();
            finish();
        }
    }
    public void setLocation (View view){
        /* reminderRange= (EditText)findViewById(R.id.reminderRange);
         Latitude=(TextView)findViewById(R.id.Latitude);
         Longitude=(TextView)findViewById(R.id.Longitude);*/

        if(TextUtils.isEmpty(reminderRange.getText().toString())) {
             /*Intent intent = new Intent(getApplicationContext(),customizeTask.class);
             startActivity(intent);*/

            Toast.makeText(this,"Please enter the radius ",Toast.LENGTH_LONG).show();

        }else{
            Double rr=Double.valueOf(reminderRange.getText().toString()).doubleValue();
            Intent intent = new Intent(getApplicationContext(), MapsActivity.class);
            intent.putExtra("rr",rr);
            //  Latitude.setText(Double.toString(lt));
            //Longitude.setText(Double.toString(lg));
            startActivity(intent);

        }

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_customize_task);
        reminderRange= (EditText)findViewById(R.id.reminderRange);
        Latitude=(TextView)findViewById(R.id.Latitude);
        Longitude=(TextView)findViewById(R.id.Longitude);
        taskName=(EditText)findViewById(R.id.taskName);
       // savebtn=(Button)findViewById(R.id.button2);
        data=new Data();
        ref= FirebaseDatabase.getInstance().getReference().child("Members");

        /*savebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
              /*  String task=taskName.getText().toString().trim();
                String latitude=Latitude.getText().toString().trim();
                String longitude=Longitude.getText().toString().trim();
                String remRange=reminderRange.getText().toString().trim();


                data.setTask(task);
                data.setLat(latitude);
                data.setLon(longitude);
                data.setRadius(remRange);
                ref.push().setValue(data);

                Toast.makeText(customizeTask.this,"Data added Successfully",Toast.LENGTH_SHORT).show();

                startActivity(new Intent(customizeTask.this,MainActivity.class));


            }
        }); */
        Intent intent = getIntent();
        Toast.makeText(this,Integer.toString(intent.getIntExtra("item number",0)),Toast.LENGTH_LONG).show();

    }
}