package com.example.reminder;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.widget.Toast;

public class GeofenceBroadcastReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {

        Toast.makeText(context, "Geofence Triggered...", Toast.LENGTH_SHORT).show();

        throw new UnsupportedOperationException("Not yet implemented");
    }
}
